package com.example.themxoasuasanpham.model.spinner;

public class CategorySpinner {
    private String name;

    public CategorySpinner(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
