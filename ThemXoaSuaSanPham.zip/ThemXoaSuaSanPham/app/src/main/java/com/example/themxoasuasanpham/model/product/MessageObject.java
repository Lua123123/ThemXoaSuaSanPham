package com.example.themxoasuasanpham.model.product;

public class MessageObject {
}
